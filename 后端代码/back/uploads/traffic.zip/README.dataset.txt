# Traffic Light Distinction > 2024-03-20 8:49pm
https://universe.roboflow.com/sep742-pn4fw/traffic-light-distinction

Provided by a Roboflow user
License: CC BY 4.0

